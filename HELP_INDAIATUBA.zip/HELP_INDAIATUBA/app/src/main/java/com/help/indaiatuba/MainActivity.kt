package com.help.indaiatuba

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.help.indaiatuba.databinding.ActivityMainBinding
import com.help.indaiatuba.ui.SearchingActivity

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val services = resources.getStringArray(R.array.service_types)
        binding.spinnerTipo.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, services)

        binding.btnSolicitar.setOnClickListener {
            val tipo = binding.spinnerTipo.selectedItem?.toString() ?: ""
            val descricao = binding.inputDescricao.text.toString()
            val bairro = binding.inputBairro.text.toString()
            val horario = binding.inputHorario.text.toString()

            if (tipo.isBlank() || descricao.isBlank() || bairro.isBlank() || horario.isBlank()) {
                Toast.makeText(this, R.string.preencha_tudo, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val i = Intent(this, SearchingActivity::class.java).apply {
                putExtra("tipo", tipo)
                putExtra("descricao", descricao)
                putExtra("bairro", bairro)
                putExtra("horario", horario)
            }
            startActivity(i)
        }
    }
}
