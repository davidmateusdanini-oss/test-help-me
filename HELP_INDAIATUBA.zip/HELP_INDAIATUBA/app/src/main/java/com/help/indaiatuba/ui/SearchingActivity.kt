package com.help.indaiatuba.ui

import android.content.Intent
import android.graphics.drawable.AnimationDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.help.indaiatuba.databinding.ActivitySearchingBinding

class SearchingActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySearchingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySearchingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        (binding.imageFootsteps.drawable as? AnimationDrawable)?.start()

        Handler(Looper.getMainLooper()).postDelayed({
            binding.groupFound.visibility = View.VISIBLE
            binding.btnVerOpcoes.visibility = View.VISIBLE
        }, 2500)

        binding.btnVerOpcoes.setOnClickListener {
            val i = Intent(this, ResultsActivity::class.java).apply {
                putExtras(intent.extras ?: Bundle())
            }
            startActivity(i)
            finish()
        }
    }
}
